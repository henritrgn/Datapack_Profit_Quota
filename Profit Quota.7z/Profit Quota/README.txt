You initialize the function schedule_update and scheduled_dashboard at the beggining with (only one time) the command :

/function score:init

in the Minecraft tchat or in a regular command block



Another possibility is to do the command :

/function mon_pack:spawn_command_block

which will create a command block with the init method inside.
