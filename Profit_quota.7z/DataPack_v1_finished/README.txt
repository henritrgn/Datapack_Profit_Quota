You initialize the function schedule_update and scheduled_dashboard at the beggining with (only one time) the command :
/function score:init
in the Minecraft tchat or in a regular command block
