That's the schedule_dashboard you need to launch at the beggining of your adventure so it works properly :
/function mon_pack:scheduled_dashboard
